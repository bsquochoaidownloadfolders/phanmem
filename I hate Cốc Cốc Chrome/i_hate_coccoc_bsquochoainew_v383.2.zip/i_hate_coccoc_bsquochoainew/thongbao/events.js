﻿chrome.runtime.onMessage.addListener(
  function(req, sender, sendResponse) {
    if (req.ham == "read"){
		switch (req.t) {
			case "pause":
				chrome.tts.pause();
				break;
			case "resume":
				chrome.tts.resume()
				break;
			case "speak":
				speek(req.d)
				break;
		}
	}
	else if ( req.ham == "luutu") {
		switch (req.t) {
			case "luu":
				if (localStorage.st == null ){localStorage.st = 0}
				var st = Number(localStorage.st)
				var trungkhong = 0
				for (i = st-1; i >= st-5; i--) { //check 5 tu gan nhat xem co trung k
					if( req.c == localStorage.getItem("tc"+i) ){
						trungkhong = 1
						break;
					}
					else {trungkhong = 0}
				}
				if (req.c.toString().length <= 131 && trungkhong == 0){
					savetu(req.c, req.u)
				}
				break;
			case "lay":
				break;
		}
	}
	else if (req.ham == "downloadzingmp3"){
		var downloadoptions = {url:req.link, filename:req.name.replace(/(\\|\/|\:|\*|\?|\"|\<|\>|\|)/g, "")}
		console.log(downloadoptions.filename)
		chrome.downloads.download(downloadoptions, function(){})
	}
	else if (req.ham == "taixuongyoutube"){
		chrome.windows.create({
		 type: 'detached_panel',
		 url: req.u,
		 width:Math.round(screen.width*80/100),
		 height: 400,
		 left: 100,
		 top: 100
		}, function (newWindow) {});
	}
	else if (req.ham == "hdviet"){
		localStorage.setItem(req.name, req.val) //hdviet_chatluongphim va hdviet_phude
	}
	else if (req.ham == "hdvietdownload"){
		chrome.downloads.download({url: req.link}, function(downloadid){})
	}
});
if (localStorage.gtngonngu == null){localStorage.gtngonngu = "vi"}
if (localStorage.batphanmem == null){localStorage.batphanmem = "1"}
if (localStorage.gender == null ) {localStorage.gender = "female"}
if (localStorage.lang == null ) {localStorage.lang = "en-US"}
if (localStorage.rate == null ) {localStorage.rate = "0.9"}
if (localStorage.volume == null ) {localStorage.volume = "1"}
if (localStorage.cddoc == null ) {localStorage.cddoc = "cddocgt"}
if (localStorage.cdnguondich == null ) {localStorage.cdnguondich = "cddichgt"}
if (localStorage.cdrechuot == null ) {localStorage.cdrechuot = "0"}

//Long live connect lấy Cài đặt nhanh bên context
chrome.runtime.onConnect.addListener(function(port) {
  console.assert(port.name == "caidatnhanh");
  port.onMessage.addListener(function(m) {
		if (m.data = "cd"){
			port.postMessage({cddoc: localStorage.cddoc, cdhighlight:localStorage.cdhighlight, cdnghedoc:localStorage.cdnghedoc, cdluutu:localStorage.cdluutu, cdhientudien:localStorage.cdhientudien, cddoctiengviet:localStorage.cddoctiengviet, gtdocngonngu:localStorage.gtdocngonngu, gttudien:localStorage.gttudien, batphanmem: localStorage.batphanmem, cdnguondich:localStorage.cdnguondich, cdrechuot: localStorage.cdrechuot});
		}
  });
});

chrome.webRequest.onBeforeRequest.addListener(
        function(details) { return {cancel: true}; },
        {urls: ["http://d1.violet.vn/ads/*", "http://s.ad360.vn/*", "http://static.adtimaserver.vn/*", "http://rtax.criteo.com/delivery/*", "http://api.adtimaserver.vn/*","http://asianmedia.com/GAAN/www/delivery/*", "*://*.adtimaserver.vn/*", "*://ad.doubleclick.net/*", "*://*.revsci.net/*", "*://adi.vcmedia.vn/*", "*://admicro1.vcmedia.vn/*","*://*.g.doubleclick.net/*","*://www.googleadservices.com/pagead/", "*://*.polyad.net/*","*://s.tuoitre.vn/*", "*://stc.id.nixcdn.com/*", "*://*.chitika.net/*","*://*.adk2x.com/*","*://*.2xbpub.com/*","*://*.ad131m.com/*","*://*.vetv.vn/*","*://vetv.vn/*", "*://*.adnetwork.vn/*", "*://*.innity.net/*", "*://*.gamelumi.com/*", "*://*.somo.vn/*", "*://*.adtop.vn/*", "*://*.adsquangcao.com/*", "*://*.m-viet.com/*", "*://*.adsvidsdouble.com/*", "*://adsvidsdouble.com/*", "*://*.padstm.com/*", "*://cdn.engine.4dsply.com/*", "*://coinurl.com/*", "*://clktag.com/*", "*://clkrev.com/*", "*://eclkmpbn.com/*", "*://*.oclaserver.com/*", "*://asset.pagefair.net/*", "*://ads.uptobox.com/*", "*://*.directrev.com/*", "*://*.bentdownload.com/*", "*://*.click.aliexpress.com/*", "*://c.eclick.vn/*", "*://s.eclick.vn/*", "*://*.terraclicks.com/*", "*://*.edomz.net/*", "*://*.popads.net/*", "*://go.oclasrv.com/*", "*://*.popcash.net/*", "*://clktag.com/adServe/*", "*://eclkspbn.com/adServe/*", "*://eclkmpsa.com/adServe/*", "*://*.clkoffers.com/*", "*://yllix.com/*", "*://resources.infolinks.com/*", "*://cdn.shorte.st/link-converter.min.js", "*://*.clicksor.net/*", "*://*.exoclick.com/*", "*://*.anthill.vn/*","*://*.pub2srv.com/*","*://onclickads.net/*", "*://*.novanet.vn/*", "*://cdn.ouo.io/js/full-page-script.js", "http://cm.tuoitre.vn/like/unlikecomment/"]},
        ["blocking"]);

//Các trang quảng cáo video
chrome.webRequest.onBeforeRequest.addListener(function(details){
			if(details.url.indexOf(".mp4") > 0 || details.url.indexOf(".flv") > 0){
				return {redirectUrl: chrome.extension.getURL('site/inSite/mp4/ads.mp4')}
			}
	},
	{urls: ["*://*.blueseed.tv/*", "*://*.serving-sys.com/*","*://*.videologygroup.com/*", "*://*.adnetwork.vn/*", "*://*.cdnviet.com/*"]},
	["blocking"])

//toomva.com
chrome.webRequest.onBeforeRequest.addListener(function(details){
		if(details.url.indexOf("videoController.js") > 0){
			return {redirectUrl: chrome.extension.getURL('site/inSite/toomva/videoController.js')}
		}
},
{urls: ["*://*.toomva.com/*", "*://toomva.com/*"]},
["blocking"])

//tuoitre.vn
chrome.webRequest.onBeforeRequest.addListener(function(details){
		if(details.url.indexOf("comment/js/function.js") > 0){
			return {redirectUrl: chrome.extension.getURL('site/inSite/tuoitre/function.js')}
		}
},
{urls: ["*://*.tuoitre.vn/*"]},
["blocking"])

//hdviet.com
/* 	chrome.webRequest.onBeforeRequest.addListener(function(details){
			if(details.url.indexOf(".ts") > 0 && details.url.indexOf("-vip.vn-hd.com/") == -1 && details.url.indexOf("clip.") == -1){
				q = {b270: 700000, b360:1000000, b450:15000000, bmHD: 2000000, b720:2700000, b1080:2700000}
				return {redirectUrl: details.url.replace(/\.vn-hd/g, "-vip.vn-hd").replace(/700000_/g, q.bmHD+"_").replace(/1000000_/g, q.bmHD+"_").replace(/1500000_/g, q.bmHD+"_") }
			}
	},
	{urls: ["*://*.vn-hd.com/*"]},
	["blocking"])
	chrome.webRequest.onBeforeRequest.addListener(function(details){
			q = {b320: 320, b480:480, b640:640, b800: 800, b1024:1024, b1280:1280, b1920: 1920}
			macdinh =q.b1280
			if(details.url.indexOf(".ts") > 0 || details.url.indexOf(".m3u8") > 0 && details.url.indexOf("/"+macdinh) == -1 && details.url.indexOf("playlist.m3u8") == -1){
				return {redirectUrl: details.url.replace(/\/480/g,"/"+macdinh).replace(/\/640/g,"/"+macdinh).replace(/\/320/g,"/"+macdinh).replace(/\/800/g,"/"+macdinh)}
			}
	},
	{urls: ["*://*.flix-cdn.com/*"]},
	["blocking"])
 */
/*  chrome.webRequest.onBeforeRequest.addListener(function(details){
			if(details.url.indexOf("/jwplayer.js") != -1){
				return {redirectUrl: chrome.extension.getURL('site/inSite/jwplayer/jwplayer.js')}
			}
	},
	{urls: ["*://t.hdviet.com/*"]},
	["blocking"])  */
chrome.webRequest.onBeforeRequest.addListener(function(details){
			if(details.url.indexOf("/hdv.v2.info.min.js") != -1){
				return {redirectUrl: chrome.extension.getURL('site/inSite/hdviet/hdv.v2.info.js')}
			}
			if(details.url.indexOf("/jwplayer.js") != -1){
				return {redirectUrl: chrome.extension.getURL('site/inSite/hdviet/jwplayer.js')}
			}
	},
	{urls: ["*://t.hdviet.com/*"]},
	["blocking"])
chrome.webRequest.onBeforeRequest.addListener(function(details){
			if(details.url.indexOf("/episode-video.min.js") != -1){
				return {redirectUrl: chrome.extension.getURL('site/inSite/kites/episode-video.min.js')}
			}
	},
	{urls: ["*://skin.kites.vn/*"]},
	["blocking"])

chrome.webRequest.onBeforeRequest.addListener(function(details){
		if(details.url.indexOf("playlist.m3u8") > 0 && details.url.indexOf("playlist.m3u8?") == -1 ){
			chrome.tabs.executeScript(details.tabId, {
				code: 'localStorage.bsquochoai_playlistm3u8="'+details.url+'"'
			})
			chrome.tabs.executeScript(details.tabId, {
				file: 'site/inSite/hdviet/injectscript.js'
			})
		}
},
{urls: ["*://*.vn-hd.com/*"]},
["blocking"])

chrome.webRequest.onBeforeRequest.addListener(function(details){
		if(details.url.indexOf(".srt") > 0){
			chrome.tabs.executeScript(details.tabId, {
				code: 'localStorage.bsquochoai_subtitles="'+details.url+'"'
			})
		}
},
{urls: ["*://*.vn-hd.com/*"]},
["blocking"])

//Zing mp3 video
chrome.webRequest.onBeforeRequest.addListener(function(details){
		if(details.url.indexOf(".swf") != -1  && details.url.indexOf(".zingmp3.movie") != -1 ){
			chrome.tabs.executeScript(details.tabId, {
				file: 'site/inSite/zingmp3-video/injectscript.js'
			})
			return {cancel: true};
		}
},
{urls: ["*://static.mp3.zdn.vn/*"]},
["blocking"])

//Zing tv video
chrome.webRequest.onBeforeRequest.addListener(function(details){
		if(details.url.indexOf(".swf") != -1  && details.url.indexOf("ZingTV") != -1 ){
			chrome.tabs.executeScript(details.tabId, {
				file: 'site/inSite/zingtv/injectscript.js'
			})
			return {cancel: true};
		}
},
{urls: ["*://stc-tv.zing.vn/*"]},
["blocking"])

//Zing tv video
chrome.webRequest.onBeforeRequest.addListener(function(details){
		if(details.url.indexOf("download.js") != -1){
			return {redirectUrl: chrome.extension.getURL('site/inSite/fshare/download.js')}
		}
},
{urls: ["*://*.fshare.vn/*"]},
["blocking"])

//olm.vn
chrome.webRequest.onBeforeRequest.addListener(function(details){
		if(details.url.indexOf("math.js") != -1){
			return {redirectUrl: chrome.extension.getURL('site/inSite/olmvn/math.js')}
		}
},
{urls: ["*://olm.vn/*"]},
["blocking"])

//123doc
chrome.webRequest.onBeforeRequest.addListener(function(details){
		if(details.url.indexOf("detail.js") != -1){
			return {redirectUrl: chrome.extension.getURL('site/inSite/123doc/detail.js')}
		}
		if(details.url.indexOf("script.js") != -1){
			return {redirectUrl: chrome.extension.getURL('site/inSite/123doc/script.js')}
		}
},
{urls: ["*://static.store123doc.com/*"]},
["blocking"])

//linksvip
chrome.webRequest.onBeforeRequest.addListener(function(details){
		if(details.url.indexOf("LinksVIP.js") != -1){
			return {redirectUrl: chrome.extension.getURL('site/inSite/linksvip/LinksVIP.js')}
		}
},
{urls: ["*://linksvip.net/*"]},
["blocking"])

//Chỉnh Access-Control-Allow-Origin
chrome.webRequest.onHeadersReceived.addListener(function(details){
	details.responseHeaders.forEach(function(v,i,a){
		if(v.name == "access-control-allow-origin"){
			details.responseHeaders.splice(i,1);
		}
	});
	details.responseHeaders.push({name:"Access-Control-Allow-Origin",value:"*"});
   return {responseHeaders:details.responseHeaders};
},
{urls: ["*://*.vn-hd.com/*", "*://api.mp3.zing.vn/*", "*://api.tv.zing.vn/*", "*://*.youtube.com/*", "*://keepvid.com/*"]},["responseHeaders","blocking"]);

//tienganh123.com
chrome.webRequest.onBeforeRequest.addListener(function(details){
			if(details.url.indexOf("/js/game.js") > 0){
				return {redirectUrl: chrome.extension.getURL('site/inSite/tienganh123/gamevip.js')}
			}
			if(details.url.indexOf("/dungchung/function.js") > 0){
				return {redirectUrl: chrome.extension.getURL('site/inSite/tienganh123/function.js')}
			}
			if(details.url.indexOf("/js/audio_ddn.js") > 0){
				return {redirectUrl: chrome.extension.getURL('site/inSite/tienganh123/audio_ddn.js')}
			}
			if(details.url.indexOf("/js/jquery_ready.js") > 0){
				return {redirectUrl: chrome.extension.getURL('site/inSite/tienganh123/jquery_ready.js')}
			}
			if(details.url.indexOf("/js/libs_audio.js") > 0){
				return {redirectUrl: chrome.extension.getURL('site/inSite/tienganh123/libs_audio.js')}
			}
			if(details.url.indexOf("/olympic/js/action.js") > 0){
				return {redirectUrl: chrome.extension.getURL('site/inSite/tienganh123/action.js')}
			}
			if(details.url.indexOf("basic/js/basic_action.js") > 0){
				return {redirectUrl: chrome.extension.getURL('site/inSite/tienganh123/basic_action.js')}
			}
	},
	{urls: ["*://*.tienganh123.com/*"]},
	["blocking"]) 

	//Google Recaptcha
chrome.webRequest.onBeforeRequest.addListener(function(details){
			if(details.url.indexOf("recaptcha__en.js") > 0){
				return {redirectUrl: chrome.extension.getURL('site/plugins/recaptcha__en.js')}
			}
	},
	{urls: ["*://*.gstatic.com/recaptcha/*"]},
	["blocking"]) 
	
 chrome.webRequest.onBeforeSendHeaders.addListener(
        function(details) {
			if (details.url.indexOf("translate.google.com.vn/translate_tts") > 0){
				 for (var i = 0; i < details.requestHeaders.length; ++i) {
					if (details.requestHeaders[i].name === 'Referer') {
					  details.requestHeaders[i].value = "https://translate.google.com.vn/translate_tts?ie=UTF-8&editfrom=bsquochoai.ga"
					  break;
					}
				}
          } //if details.url
			 else if (details.url.indexOf("translate.google.com/m?") > 0){
				 for (var i = 0; i < details.requestHeaders.length; ++i) {
					if (details.requestHeaders[i].name === 'Referer') {
					  details.requestHeaders[i].value = "https://translate.google.com/m?editfrom=bsquochoai.ga"
					  break;
					}
				}
			 }
          return {requestHeaders: details.requestHeaders};
        },
        {urls: ["<all_urls>"]},
        ["blocking", "requestHeaders"]);
		  
//Command keyboard shortcut
chrome.commands.onCommand.addListener(function(cmd) {
   if (cmd == "doclai"){
		 if(localStorage.cddoc == "cddocchuan"){
				chrome.storage.local.get('tumoidoc', function (re) {
					 chrome.runtime.sendMessage({ham: "read",t:"speak", d: re.tumoidoc})
				});
			} else if(localStorage.cddoc == "cddocgt"){
				/* chrome.tabs.getCurrent(function(tab){
					chrome.tabs.executeScript(tab.id, {code:''}, function(){})
				}) */
			}
	} else if (cmd=="battatphanmem"){
		if ( localStorage.batphanmem =="1" ){
			localStorage.setItem("batphanmem","0")
			options= {
					type:"basic",
					title:"Đã tắt!",
					iconUrl:"/icon/icon128.png",
					message:"Em hãy bấm Alt+Q lần nữa để bật phần mềm."
				}
				chrome.notifications.create("tb", options,function(){})
		} else {
			localStorage.setItem("batphanmem","1")
			options= {
					type:"basic",
					title:"Đã bật!",
					iconUrl:"/icon/icon128.png",
					message:"Em hãy bấm Alt+Q lần nữa để tắt phần mềm."
				}
				chrome.notifications.create("tb", options,function(){})
			
		}
	} else if (cmd=="momaytinhcasio"){
		var w = Math.round(screen.width*80/100)
		var h =Math.round(screen.height*85/100)
		var l = Math.round((screen.width/2)-(w/2));
		var t = Math.round((screen.height/2)-(h/2));
		chrome.windows.create({
		 type: 'detached_panel',
		 url: "http://web2.0calc.com/",
		 width:w,
		 height: h,
		 left: l,
		 top: t
		}, function (newWindow) {
		});
	}
});
setInterval(function(){
	chrome.notifications.clear("tb", function(){})
},10000)
chrome.notifications.onClicked.addListener(function(nid,byuser){
	chrome.notifications.clear(nid, function(){
	})
})
var now = new Date();
var thoigianhoc = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 19, 55, 00, 0) ;
chrome.alarms.create("alarmhocanhvancungthay", {
	when: thoigianhoc.getTime(),
	periodInMinutes: 24*60*60
})
chrome.alarms.onAlarm.addListener(function(a){
	if(a.name="alarmhocanhvancungthay"){
		chrome.notifications.create("hocanhvan", {
					type:"basic",
					title:"Tới giờ HỌC ANH VĂN CÙNG THẦY!",
					iconUrl:"/icon/icon128.png",
					message:"20:00 hôm nay trên AloAlo, em hãy nhanh chóng chuẩn bị để học cùng thầy và các bạn nhen."
				},function(){})
		//chrome.tts.speak("It's time to study English with thayy bs walk why, please open Alo Alo to learn at 8 o'clock!");
	}
})
function savetu(c,u){
	var st = Number(localStorage.st)
	var l =""
	if (localStorage.cddoc == "cddocgt"){ l=localStorage.gtdocngonngu }
	else { l=localStorage.lang }
	var d = new Date()
	var t = d.getTime()
	localStorage.setItem("tc"+st, c )
	localStorage.setItem("tl"+st, l )
	localStorage.setItem("tu"+st, u )
	localStorage.setItem("tt"+st, t)
	
	localStorage.setItem('st',st+1 )
}
function taowindow(url){
		var w = Math.round(screen.width*80/100)
		var h =Math.round(screen.height*85/100)
		var l = Math.round((screen.width/2)-(w/2));
		var t = Math.round((screen.height/2)-(h/2));
		chrome.windows.create({
		 type: 'detached_panel',
		 url: url,
		 width:w,
		 height: h,
		 left: l,
		 top: t
		}, function (newWindow) {
		});
}
function speek(t){
	chrome.tts.stop()
	var lang = localStorage.lang
	var gender = localStorage.gender
	var rate = Number(localStorage.rate)
	var volume = Number(localStorage.volume)
	chrome.tts.speak(t, {'gender':gender, 'lang':lang, 'rate': rate, 'volume':volume });
}
function x(x){console.log(x)}
