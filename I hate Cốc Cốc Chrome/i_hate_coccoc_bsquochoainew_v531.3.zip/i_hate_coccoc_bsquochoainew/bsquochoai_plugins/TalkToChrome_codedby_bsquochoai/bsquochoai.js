﻿ulti = {
	lenh: {
		data: {
			"gmail": {action: "moTab("+JSON.stringify({link: 'https://mail.google.com/mail/u/0/#inbox'})+")"},
			"gửi mail": {action: "moTab("+JSON.stringify({link: 'https://mail.google.com/mail/u/0/#inbox'})+")"},
			"facebook": {action: "moTab("+JSON.stringify({link: 'https://facebook.com'})+")"},
			"youtube": {action: "moTab("+JSON.stringify({link: 'https://youtube.com'})+")"},
			"báo tuổi trẻ": {action: "moTab("+JSON.stringify({link: 'http://tuoitre.vn'})+")"},
			"báo 24 giờ": {action: "moTab("+JSON.stringify({link: 'http://www.24h.com.vn'})+")"},
			"học anh văn": {action: "moTab("+JSON.stringify({link: 'http://av.bsquochoai.ga'})+")"},
			"zing mp3": {action: "moTab("+JSON.stringify({link: 'http://mp3.zing.vn'})+")"},
			"youtube của tôi" : {action: "moTab("+JSON.stringify({link: 'https://www.youtube.com/my_videos?o=U'})+")"}
		},
		chrome: {
			"cài đặt": "settings",
			"phím tắt": "extensions/configureCommands",
			"download": "downloads",
			"tải xuống": "downloads",
			"extension": "extensions",
			"phần mở rộng": "extensions",
			"bút máy": "bookmarks",
			"phiên bản": "chrome",
			"các ứng dụng": "apps",
			"lịch sử": "history"
		},
		mo: {
			"vẽ đồ thị": "Chromedothi_by_hoai/index.html",
			"máy tính":"Chromemaytinh_by_hoai/index.html",
			"từ điển":"{send}",
			"màn hình":"{send}",
			"đổi ip": "ChromeVPN_by_hoai/caidat.html"
		},
		fix: {
			keo: {"kiểu súng" : "kéo xuống", "cá vàng": "kéo về", "kể về": "kéo về", "kéo vàng": "kéo về", "ceo là": "kéo ra", "cao lan": "kéo lên"},
			dong: {"đồng hồ bên phải": "đóng hết bên phải", "tổng hợp bên phải": "đóng hết bên phải", "đóng cửa khẩu": "đóng cửa sổ"}
		},
		moTab: function(data){
			chrome.tabs.create({url: data.link})
		},
		lenhMo: function(lenh){
			cquery = lenh.substring(3)
			if (typeof ulti.lenh.mo[cquery] != "undefined" &&  ulti.lenh.mo[cquery] != "{send}"){
				ulti.lenh.moTab({link:  "/bsquochoai_plugins/"+ulti.lenh.mo[cquery]})
			} else if(ulti.lenh.mo[cquery] == "{send}"){
				chrome.runtime.sendMessage({ham: "talktochrome", type: "mo", lenh: cquery})
			}
		},
		lenhKeo: function(lenh){
			cquery = lenh.substring(4)
			chrome.runtime.sendMessage({ham: "talktochrome", type: "keo", lenh: cquery})
		},
		lenhMoTab: function(lenh){
			cquery = Number(lenh.substring(6).trim())
			chrome.runtime.sendMessage({ham: "talktochrome", type: "tab", action: "motab", lenh: cquery})
		},
		lenhDongTab: function(lenh){
			cquery = lenh.substring(5)
			chrome.runtime.sendMessage({ham: "talktochrome", type: "tab", action: "dongtab", lenh: cquery})
		}
	}
}

$(function(){
	init()
	chrome.storage.local.get("bs_talktochrome", function(re){
		sound(re.bs_talktochrome.caidat)
	})
	
})
function init(){
	ngonngumacdinh = "vi-VN"
	//Chọn ngôn ngữ
	ngonngu = [
	{t: "Tiếng Việt", v: "vi-VN"},
	{t: "English", v:"en-US"}
	]
	$.each(ngonngu, function(k,v){
		$("#cd-ngonngu").append('<option value="'+v.v+'">'+v.t+' ('+v.v+')</option>')
	})
	//Cài đặt các giá trị cài đặt mặc định
	chrome.storage.local.get("bs_talktochrome", function(re){
		if(typeof re.bs_talktochrome == "undefined"){
			re.bs_talktochrome = {caidat: {ngonngu: ngonngumacdinh}};
			chrome.storage.local.set(re)
		}
		$('[data-caidat-select]').each(function(){
			$(this).val(re.bs_talktochrome.caidat.ngonngu)
		})
	})
	//Cài đặt các thay đổi
	$('[data-caidat-select]').change(function(){
		thisLocalStorage = $(this).data("caidat-select")
		thisPointer = $(this).data("caidat-pointer")
		thisValue = $(this).val()
		chrome.storage.local.get("bs_talktochrome", function(re){
			re.bs_talktochrome.caidat[thisLocalStorage] = thisValue
			chrome.storage.local.set(re, function(){
				window.location.reload()
			})
		})
	})
}
function sound(caidat){
	var recognition = new webkitSpeechRecognition();
	recognition.continuous = false ;
	recognition.interimResults = true;
	recognition.lang = caidat.ngonngu
	recognition.onresult = function(event) {
    var interim_transcript = '';
	 final_transcript = ""
    if (typeof(event.results) == 'undefined') {
      recognition.onend = null;
      recognition.stop();
      return;
    }
    for (var i = event.resultIndex; i < event.results.length; ++i) {
      if (event.results[i].isFinal) {
        final_transcript += event.results[i][0].transcript;
      } else {
        interim_transcript += event.results[i][0].transcript;
      }
    }
	 if(interim_transcript != "")$(".bs_interim").html(interim_transcript)
    if (final_transcript != "") {
		nhanlenh(final_transcript);
      $(".bs_caclenhdara").prepend('<p>'+final_transcript+'</p>')
		$(".bs_interim").html("<em>Hãy nói tiếp để ra lệnh cho Chrome</em>")
		window.recognition.abort()
    }
  };
	window.recognition = recognition
  window.recognition.onend = function(){
		console.log("end")
		window.recognition.start()
  }
  window.recognition.onstart = function(){
		console.log("start")
  }
	window.recognition.start()
}

function nhanlenh(lenh){
		lenh = lenh.trim()
		if(typeof ulti.lenh.data[lenh] != "undefined"){
			action = ulti.lenh.data[lenh].action
			cfunc = action.replace(/\(.*\)/g, "")
			cbien = action.match(/\(.*\)/g)[0].replace(/(\(|\))/g, "")
			window.ulti.lenh[cfunc](JSON.parse(cbien))
		} else if (lenh.substring(0,3) == "tìm"){
			gquery = lenh.substring(4)
			ulti.lenh.moTab({link:  'https://www.google.com/search?q='+encodeURIComponent(gquery)+'&rct=j'})
		}  else if (lenh.substring(lenh.length - 8) == "tìm kiếm"){
			gquery = lenh.substring(0, lenh.length - 9)
			ulti.lenh.moTab({link:  'https://www.google.com/search?q='+encodeURIComponent(gquery)+'&rct=j'})
		} else if (lenh.indexOf("cờ rôm") == 0 || lenh.indexOf("rom") == 0 || lenh.indexOf("chrome") == 0 || lenh.indexOf("crom") == 0){
			cquery = lenh.replace("cờ rôm", "").replace("chrome", "").replace("rom", "").replace("crom", "").trim()
			console.log(cquery)
			if (typeof ulti.lenh.chrome[cquery] != "undefined")
			ulti.lenh.moTab({link:  "chrome://"+ulti.lenh.chrome[cquery]})
		} else if (["mở"].indexOf(lenh.substring(0,2)) == 0  ){
			if(lenh.indexOf("tập") == 3 || lenh.indexOf("tab") == 3|| lenh.indexOf("tap") == 3){
				ulti.lenh.lenhMoTab(lenh)
			} else {
				ulti.lenh.lenhMo(lenh)
			}
		} else if (["kéo"].indexOf(lenh.substring(0,3)) == 0 || ulti.lenh.fix.keo.hasOwnProperty(lenh)){
			if(ulti.lenh.fix.keo.hasOwnProperty(lenh)) lenh = ulti.lenh.fix.keo[lenh];
			ulti.lenh.lenhKeo(lenh)
		} else if (["đóng"].indexOf(lenh.substring(0,4)) == 0 || ulti.lenh.fix.dong.hasOwnProperty(lenh)){
			if(ulti.lenh.fix.dong.hasOwnProperty(lenh)) lenh = ulti.lenh.fix.dong[lenh];
			ulti.lenh.lenhDongTab(lenh)
		}
}



