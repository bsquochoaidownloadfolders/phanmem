jwplayer(HDV.V2.PlayerMedium.name).remove();
jwplayer = undefined
//jwplayer(HDV.V2.PlayerMedium.name).play()