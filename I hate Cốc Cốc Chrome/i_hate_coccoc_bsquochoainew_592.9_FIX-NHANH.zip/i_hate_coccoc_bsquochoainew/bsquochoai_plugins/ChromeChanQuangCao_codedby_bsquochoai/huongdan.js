$(function(){
	bschrome.init()
})