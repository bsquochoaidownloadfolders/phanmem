﻿$("head").append("<style> .ad-showing .video-ads{display:none}</style>")
$(".ytp-volume-hover-area").after('<input id="tuchoilai" type="checkbox" name="tuchoilai" value="tuchoilai" style="margin-top: 7px;cursor:pointer"><label for="tuchoilai" style="position: relative;top: -2px;cursor:pointer">Tự chơi lại</label>')
if(localStorage.tuchoilai == null){localStorage.tuchoilai ="1"}
setInterval( function(){
	if ( $(".videoAdUiSkipButton").length >= 1 ){
		$(".videoAdUiSkipButton").trigger("click")
	}
	if(localStorage.tuchoilai == "1"){
		if ( $(".ytp-button-replay").length >0 ){
			$(".ytp-button-replay").append("<button id='btnreplay'></button>")
			$("#btnreplay").trigger("click")
		}
	}
}, 500)

$("#tuchoilai").change(function(){
	if($(this).is(':checked')){localStorage.tuchoilai = "1"}
	else {localStorage.tuchoilai = "0"}
})

if(localStorage.tuchoilai == "1"){$("#tuchoilai").attr("checked","checked")}
