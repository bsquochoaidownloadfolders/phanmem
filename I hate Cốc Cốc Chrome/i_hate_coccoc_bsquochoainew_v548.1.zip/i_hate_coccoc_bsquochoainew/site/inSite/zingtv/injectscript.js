$("body").append('<script src="'+chrome.extension.getURL('site/plugins/jwplayer.js')+'"></script>')
$("body").append('<script src="'+chrome.extension.getURL('site/inSite/zingtv/newplayer.js')+'"></script>')
$("body").append('<style>.bsquochoai_download{display: table;margin: auto;float: none;}</style>')