$(function(){
	if($(".linkvip").length > -1){
		window.location = $(".linkvip").attr("href")
	}
})