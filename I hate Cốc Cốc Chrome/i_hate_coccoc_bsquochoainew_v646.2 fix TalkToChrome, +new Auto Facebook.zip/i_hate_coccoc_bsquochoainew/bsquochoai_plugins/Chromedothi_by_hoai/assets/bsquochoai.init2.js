
    require(['toplevel/calculator_desktop', 'testbridge'], function (calc, TestBridge) {
      TestBridge.ready();
    });
	 
	 