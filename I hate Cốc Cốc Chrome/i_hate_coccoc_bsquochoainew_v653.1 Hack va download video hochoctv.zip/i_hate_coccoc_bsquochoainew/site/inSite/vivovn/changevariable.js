Object.defineProperty(window, "ovax",
	{ value: {}}
);
Object.defineProperty(window, "_ads",
	{ value: {}
	}
);
Object.freeze(window._ads);