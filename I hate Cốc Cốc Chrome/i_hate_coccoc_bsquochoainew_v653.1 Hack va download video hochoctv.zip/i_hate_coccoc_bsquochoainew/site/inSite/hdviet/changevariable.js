Object.defineProperty(window, "isHDVip",
	{ value: true
	}
);
Object.freeze(window.isHDVip);

Object.defineProperty(window, "BlueseedConfig",
	{ value: {ads:[]}
	}
);
Object.freeze(window.BlueseedConfig);

Object.defineProperty(window, "isShowAds",
	{ value:false
	}
);
Object.freeze(window.isShowAds);
Object.defineProperty(window, "isLogined",
	{ value:true
	}
);
Object.freeze(window.isLogined);
