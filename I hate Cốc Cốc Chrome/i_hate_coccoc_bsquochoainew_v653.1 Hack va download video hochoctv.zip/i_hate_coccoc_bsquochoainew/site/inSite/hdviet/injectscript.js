$("body").append('<script src="'+chrome.extension.getURL('site/inSite/hdviet/removeplayer.js')+'"></script>')
$("body").append('<script src="'+chrome.extension.getURL('site/plugins/jwplayer.js')+'"></script>')
$("body").append('<script src="'+chrome.extension.getURL('site/inSite/hdviet/newplayer.js')+'"></script>')