﻿$(function(){
	hienlen()
	chrome.runtime.onMessage.addListener(
	  function(msg, sender, sendResponse) {
		 if (msg.action == "taohotro"){
			if(window.taoroi == 1){
				$("a:not([data-talktochrome]").each(function(){
					$(this).prepend('<span class="bstalktochrome">'+sohientai+'</span>')
					$(this).attr("data-talktochrome", sohientai)
					sohientai++
				})
				$(".bstalktochrome").show()
			} else {
				hienlen()
			}
		 } else if (msg.action == "xoahotro"){
			$(".bstalktochrome").hide()
		 } else if (msg.action == "openlink"){
			/* link = $('a[data-talktochrome="'+msg.link+'"]').attr("href")
			if(link != "undefined"){
				window.location.assign(link)
			} else {
				$('a[data-talktochrome="'+msg.link+'"]').trigger("click")
			} */
			$('a[data-talktochrome="'+msg.link+'"]').append('<button id="bs_talktochrome_btn'+msg.link+'" class="bstalktochrome_btn"></button>')
			$('#bs_talktochrome_btn'+msg.link).trigger("click")
		 }
	 });
})
function hienlen(){
	chrome.storage.local.get("bs_talktochrome_hotroduondan", function(re){
		if( typeof re.bs_talktochrome_hotroduondan == "undefined"){
			re.bs_talktochrome_hotroduondan = {turnOn: 0, font: "7", color: "#AD0B0B"}
			chrome.storage.local.set(re)
		}
		if(re.bs_talktochrome_hotroduondan.turnOn){
			sohientai = 1
			$("body").append("<style>.bstalktochrome {color:white !important; background-color: "+re.bs_talktochrome_hotroduondan.color+"; border-radius:50%; font-size: "+re.bs_talktochrome_hotroduondan.font+"px;padding: 2px;font-weight: bold;max-width: 40px;position: relative !important;top: -5px !important;left: -2px !important;line-height: 12px;} .bstalktochrome_btn {display:none}</style>")
			$("a").each(function(){
				$(this).prepend('<span class="bstalktochrome">'+sohientai+'</span>')
				$(this).attr("data-talktochrome", sohientai)
				sohientai++
			})
			window.taoroi = 1
		}
	})
}