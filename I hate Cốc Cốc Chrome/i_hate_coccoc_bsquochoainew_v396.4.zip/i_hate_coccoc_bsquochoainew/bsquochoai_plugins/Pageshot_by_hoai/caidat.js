﻿var caidat = {
	math : "cộng thêm {value}px"
}
$(function(){
	//Click lên menu
	$("[data-bsquochoai-tab]").click(function(){
		$this = $(this)
		$("[data-bsquochoai-tab-content]").hide()
		$($this.data("open")).fadeIn(700, "swing")
		return false;
	})
	
	//Update dữ liệu cài đặt
	caidatInit()
})

 function caidatInit(){
		$("[data-caidat][type='range']").mousemove(function(){
			$this = $(this)
			lcs = $this.data("localstorage")
			$("#"+lcs).val(caidat.math.replace(/{value}/g, $this.val()));
			localStorage[lcs] = $this.val()
		})
		$.each($("[data-caidat][type='range']"), function(){
			lcs = $(this).data("localstorage")
			$(this).val(localStorage[lcs])
			$("#"+lcs).val(caidat.math.replace(/{value}/g, $(this).val()));
		})
		$("[data-caidat][type='checkbox']").change(function(){
			localStorage[$(this).data("localstorage")] = $(this).prop("checked")
		})
		$.each($("[data-caidat][type='checkbox']"), function(){
			ischecked = (localStorage[$(this).data("localstorage")].toLowerCase() === 'true');
			$(this).prop("checked", ischecked )
		})
		/* $("[data-caidat]").each(function(){
			$this = $(this)
			if($this.data("type") == "checkbox"){
				$this.change(function(){
					$(this).
				})
			}
		}) */
 }
